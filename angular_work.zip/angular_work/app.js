// app.js
var routerApp = angular.module('routerApp', ['ui.router']);

routerApp.config(function($stateProvider, $urlRouterProvider) {   

    $urlRouterProvider.otherwise('/home');  

    $stateProvider       
        // HOME STATES AND NESTED VIEWS 
        .state('home', {
            url: '/home',
            templateUrl: 'home.html'
        })

        // nested list with custom controller
        .state('home.list', {
            url: '/list',
            templateUrl: 'list.html',
            controller: function($scope) {
                $scope.funnycitynames = ['Boring Oregon City', 
				'Emba rrass Minnesota',
				'No Name South Dakota', 
				'Penistone South Yorkshire England', 
				'Intercourse Lancaster County, PA'];
            }
        })

        // nested list with just some random string data
        .state('home.anything', {
            url: '/anything',
            template: 'What do you want from ui-route'
        })
        
        // ABOUT PAGE AND MULTIPLE NAMED VIEWS
        .state('about', {
            url: '/about',
            views: {	
				// Relatively targets <div ui-view/> within index.html
				// Since our main ui-view inside the about state, we gave it a blank name.
                '': { templateUrl: 'about.html' },

                //  The child views (absolutely named)
				
                // Absolutely targets the 'coulmn1' view in this state, 'about'.
				// <div ui-view='column1'/> within about.html
                // for column #1, defines a separate controller 
                'column1@about': { 
                    templateUrl: 'column1.html',
                    controller: 'column1Controller'
                },

                // Absolutely targets the 'column2' view in the 'about' state.
				// <div ui-view='column2'/> within contacts.html
                'column2@about': { template: '<h3>Column #2!</h3> <p>Simply here</p>'},
				
				// Absolutely targets the 'bottom-row' view in the 'about' state.
				// <div ui-view='bottom-row'/> within about.html
                // for bottom row, defines a separate controller 
                'bottom-row@about': { 
                    templateUrl: 'bottom.html',
                    controller: 'bottom-rowController'
                }
            }      
        });      
});

// column1 controller that we call up in the about state
routerApp.controller('column1Controller', function($scope) {
    
    $scope.message = 'column1';
   
    $scope.galaxies = [
        {
            name: 'Milkyway Galaxy',
            distance: '27,000'
        },
        {
            name: 'Andromeda Galaxy',
            distance: '2,560,000'
        },
        {
            name: 'Sagittarius Dwarf',
            distance: '3.400,000'
        }
    ];
});

// bottom-rowController that we call up in the about state
routerApp.controller('bottom-rowController', function($scope) {
    
    $scope.message = 'This is bottom row content';
});