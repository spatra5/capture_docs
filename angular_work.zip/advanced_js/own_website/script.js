//script.js
$(document).ready(function(){

	showHideProducts();
	searchProductPage();
	
	$('#head, #user-details').hide();
	$("#user-register-form").submit(function(event){
		event.preventDefault();
		// Initializing Variables With Form Element Values
		var firstname = $('#inputFirstname').val();
		var lastname = $('#inputLastname').val();
		var email = $('#inputEmail').val();
		var password = $('#inputPassword').val();
		var gender = $('input[name=genderRadios]:checked').val(); 
		var check_agreement = $('#checkboxAgreement').is(":checked");
		
		// Initializing Variables With Regular Expressions
		var name_regex = /^[a-zA-Z]+$/;
		var email_regex = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
		var number_regex = /[0-9]/;
		var lowercase_regex = /[a-z]/;
		var uppercase_regex = /[A-Z]/;
		
		// To Check Empty Form Fields.
		if (firstname.length == 0 || lastname.length == 0 || password.length == 0 || email.length == 0 ) {
			$('#head').text("Error: All fields marked as * are mandatory.").fadeIn(1000); // This Segment Displays The Validation Rule For All Fields
			//$("#inputFirstname").parent().addClass("has-error").end().focus();
			return false;
		}
		// Validating First Name Field.
		else if (!firstname.match(name_regex) || firstname.length == 0) {
			$('#head').text("Error: For your name please use alphabets only").fadeIn(1000); // This Segment Displays The Validation Rule For Name
			$("#inputFirstname").parent().addClass("has-error").end().focus();
			return false;
		}
		// Validating last Name Field.
		else if (!lastname.match(name_regex) || lastname.length == 0) {
			$('#head').text("Error: For your name please use alphabets only").fadeIn(1000); // This Segment Displays The Validation Rule For Name
			$("#inputLastname").parent().addClass("has-error").end().focus();
			return false;
		}
		// Validating Email Field.
		else if (!email.match(email_regex) || email.length == 0) {
			$('#head').text("Error: Please enter a valid email address").fadeIn(1000); // This Segment Displays The Validation Rule For Email
			$("#inputEmail").parent().addClass("has-error").end().focus();
			return false;
		}
		// Validating Password length.
		else if(password.length < 6){
			$('#head').text("Error: Password must contain at least six characters!").fadeIn(1000);
			$("#inputPassword").parent().addClass("has-error").end().focus();
			return false;
		}
		// Validating Password to contain number
		else if(!password.match(number_regex)) {
			$('#head').text("Error: password must contain at least one number (0-9)!").fadeIn(1000);
			$("#inputPassword").parent().addClass("has-error").end().focus();
			return false;
		}
		// Validating Password to contain one lowercase letter
		else if(!password.match(lowercase_regex)) {
			$('#head').text("Error: password must contain at least one lowercase letter (a-z)!").fadeIn(1000);
			$("#inputPassword").parent().addClass("has-error").end().focus();
			return false;
		  }
		// Validating Password to contain one uppercase letter  
		else if(!password.match(uppercase_regex)) {
			$('#head').text("Error: password must contain at least one uppercase letter (A-Z)!").fadeIn(1000);
			$("#inputPassword").parent().addClass("has-error").end().focus();
			return false;
		} 
		// Validating Gender radios
		else if(!gender){
			$('#head').text("Error: Please choose you gender!").fadeIn(1000);
			return false;
		}
		// Validating Terms and Conditions checkbox
		else if(!check_agreement){
			$('#head').text("Error: Please check the terms and conditions!").fadeIn(1000);
			return false;
		} 
		else {
			$(".has-error").removeClass("has-error");
			$('#head').removeClass("alert-danger").addClass("alert-success").html("Success: Form has been submitted successfully!").fadeOut(2000,function(){				
				//Close form
				$("button.close").click();						
				$("#signup-modal").remove();
				//Greet User	
				$("h2.greetings").text("Welcome " + firstname + "!");
				createUserTable(firstname,lastname,email,gender);
			});
		}
	});
});

function searchProductPage() {
	
	var searchParam = GetQueryStringParams('q');
	
	$("#navbar_search_prod")
	.find("input").val(searchParam).end()
	.find("button").click(function(e){
		e.preventDefault();
		var search = $("#navbar_search_prod input").val();
		window.location = "products.html?q=" + search;
	});
	
	$('.products_row .product').each(function(){
		
		var searchText = $(this).find(".caption .prod_name").text();	
		filterProduct(searchParam, searchText, $(this))
    });
	
	$('.filter_prod input').keyup(function() {
		var _this = $(this)
		$('.products_row .product').each(function(){
		
			var searchTerm = _this.val();	
			var searchOption = $('.filter_prod select').val();
			console.log(".prod_" + searchOption)
			var searchText = $(this).find(".caption .prod_" + searchOption).text();
			filterProduct(searchTerm, searchText, $(this));			
		});
	});
	
	$('.clear_prod_filter').click(function() {
		
		$(".prod_category .cat_text").text('Category');
		$('.filter_prod input').val('');		
		$('.filter_price select').each(function() {
			
			var default_op = $(this).find('option:eq(0)');
			//console.log(default_op);
			default_op.attr('selected','selected');
			$(this).val(default_op.val());
		})
		$(".products_row, .products_row .product").show();
	});
	
	$('.filter_price #price_btn').click(function(e) {
		
		e.preventDefault();
		
		var minPrice = parseFloat($('.filter_price #min_price').val());
		var maxPrice = parseFloat($('.filter_price #max_price').val());
		
		$(".filter_prod input").val("");
		
		if(minPrice != "" && maxPrice != "") {
			$('.products_row .product').each(function(){
				var prodPrice =  parseFloat($(this).find(".caption .prod_price").text());

				if((prodPrice >= minPrice && prodPrice <= maxPrice)) {
					$(this).addClass("inPrice").show();
				}
				else {
					$(this).removeClass("inPrice").hide();
				}
			});
		}
	});
}

function filterProduct(searchTerm, searchText, searchElem) {
	//console.log(searchTerm + searchText + searchElem)
	if(searchTerm != "" && searchTerm != null) {
		if (searchText.toLowerCase().indexOf(searchTerm.toLowerCase()) != -1) {
			searchElem.show();
		} 
		else {
			searchElem.hide();
		}
	}
	else {
		searchElem.show();
	}
}

function GetQueryStringParams(sParam)
{
    var sPageURL = window.location.search.substring(1);
    var sURLVariables = sPageURL.split('&');
    for (var i = 0; i < sURLVariables.length; i++) 
    {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == sParam) 
        {
			return sParameterName[1];
		}
	}
}

function showHideProducts() {

	$(".prod_category .dropdown-menu li a").click(function(e) {
		
		e.preventDefault();
		$(".prod_category .cat_text").text($(this).text());
		$(".products_row").hide();
		$('#' + $(this).attr('id') + '_view').show();
	});
	$(".prod_category .cat_text").click(function(e) {
		
		e.preventDefault();
		$(".prod_category .cat_text").text('Category');
		$(".products_row").show();
	});
}

function createUserTable(firstname,lastname,email,gender){
	
	var userTable = $('<table class="table table-reflow table-sm"></table>');
	userTable.html("<thead><tr><th>Name</th><th>Email</th><th>Gender</th></tr></thead>" +
	"<tbody><tr><td>" + firstname + " " + lastname + "</td><td>" + email + "</td><td>" + gender + "</td></tr></tbody>");
	$("#user-details .table-responsive")
		.append("<h3>User profile created with the below details :</h3>")
		.append(userTable);
	$("#user-details").show();
}
