describe("Sample Test Suite", function(){
	it("should return the addition of 10 & 20 as 30", function(){
		var ans = Add(10,20);
		expect(ans).toEqual(30);
	});
	it("should return undefined if any one of the arguments is not specified", function(){
		var ans = Add(10);
		expect(ans).toEqual(NaN);
	});
	it("should return undefined if no arguments is specified", function(){
		var ans = Add();
		expect(ans).toEqual(NaN);
	});
});