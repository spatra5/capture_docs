function Add(x,y) {
	return x+y;
}
function Square(x) {
	return x*x;
}