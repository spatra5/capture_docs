#!/bin/bash -e

npm install
npm test
