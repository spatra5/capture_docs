$(document).ready(function(){
	if (window.PIE) {
        $('.box_shadow, .rounded').each(function() {
            PIE.attach(this);
        });
    }
	
	$(".contact_us_form").find("input:not(:checkbox):not(:submit)").val('');
	$(".contact_us_form").find("input:not(:checkbox):not(:submit)").keydown(function(){
		$(this).closest('.input_wrap').find('label').fadeOut();
	});
	$(".contact_us_form .submit").click(function(event) {
		
		event.preventDefault();
		var form = $("#contact_us");
		//console.log( form.find("input:not(:checkbox):not(:submit)").length)
		var password;
			
				
		form.find("input:not(:checkbox):not(:submit)").each(function(event) {
			var $this = $(this);
			arrayClass = $this.attr('class').split(' ');
			
			var bValid;	
			$.each(arrayClass, function( index, value ) {
				//console.log( index + ": " + value );
				
				switch (value) {
					case 'required':
						bValid = isRequired($this.val().replace(/^\s*|\s*$/g, ''));
						break;
					case 'fullname':
						bValid = isFullname($this.val().replace(/^\s*|\s*$/g, ''));
						break;
					case 'email':
						bValid = isEmail($this.val().replace(/^\s*|\s*$/g, ''));
						break;
					case 'url':
						bValid = isURL($this.val().replace(/^\s*|\s*$/g, ''));
						break;
					case 'password':
						password = $this.val().replace(/^\s*|\s*$/g, '')
						bValid = isPassword(password);
						break;
					case 'confirm_password':
						bValid = isConfirmPassword($this.val().replace(/^\s*|\s*$/g, ''), password);
						break;
					default:
						bValid = true;
				}
				//At least one class is not valid
				if(!bValid) {
					return false;
				}
			});
			
			//console.log(bValid)
			//Input is invalid
			
			$this.next('.error').remove();
			if(!bValid) {
				$this.after("<div class='error'>" + $(this).closest('.input_wrap').find('label').text() + " is invalid.</div>").addClass("invalid");
				$this.removeClass("valid");
			}
			else{
				$this.removeClass("invalid");
				$this.addClass("valid");
			}
			
		});
		
		var checkboxInputs = form.find("input:checkbox").map(function(index,domElement) {
			return $(domElement).attr('name');
		});
		validateCheckBoxValues(checkboxInputs);
		
		if(form.find("input.invalid").length) {
			form.find("input.invalid").eq(0).focus();
			form.find(".form_msg").html("<div class='error'>Form has error value</div>");
		}
		else {
			form.find(".form_msg").html("<div class='success'>Form has been submitted successfully</div>");
		}
	});
	
});
function validateCheckBoxValues(checkboxInputs) {	
	var checkboxGroup = $.unique(checkboxInputs);
	for (var i = 0; i < checkboxGroup.length; i++ ) {
		var checkInput = $("input[name='" + checkboxGroup[i] + "']");
		
		if(checkInput.hasClass('required') && $("input[name='" + checkboxGroup[i] + "']:checked").length <= 0 ) {
			//alert('Please check any one option for : ' + checkboxGroup[i]);
			checkInput.removeClass('valid');
			checkInput.addClass('invalid');
		}
		else {			
			checkInput.removeClass('invalid');
			checkInput.addClass('valid');
		}

	}
}
		
function isRequired(strValue) {			
	return (strValue != '');
}
function isFullname(strValue) {			
	var objRE = /^[A-Za-z]+\s?[A-Za-z]+$/;
	return (strValue != '' && objRE.test(strValue));
}
function isEmail(strValue) {
	var objRE = /^[\w-\.\']{1,}\@([\da-zA-Z-]{1,}\.){1,}[\da-zA-Z-]{2,}$/;
	
	if(strValue != '' && objRE.test(strValue)) {
		var domain = strValue.split("@")[1];
		return (domain != 'sapient.com')
	}
	return false;
}
function isURL(strValue) {
	var objRE = /^(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?$/;
	return (strValue != '' && objRE.test(strValue));
}
function isPassword(strValue) {
	var objRE = /^[\w\@\`\$\&\*\%]{6,}$/;
	return (strValue != '' && objRE.test(strValue));
}
function isConfirmPassword(strValue, testValue) {
	return (strValue == testValue);
}